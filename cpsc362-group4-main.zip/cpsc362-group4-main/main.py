import chess_Engine
import sys

if __name__ == "__main__":
	Chess = chess_Engine.Chess_Board()
	sys.exit(Chess.start_game())